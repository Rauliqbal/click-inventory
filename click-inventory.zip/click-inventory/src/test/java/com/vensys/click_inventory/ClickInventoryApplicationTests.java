package com.vensys.click_inventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClickInventoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
