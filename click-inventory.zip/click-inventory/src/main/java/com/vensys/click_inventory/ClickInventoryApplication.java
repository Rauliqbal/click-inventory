package com.vensys.click_inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClickInventoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClickInventoryApplication.class, args);
	}

}
